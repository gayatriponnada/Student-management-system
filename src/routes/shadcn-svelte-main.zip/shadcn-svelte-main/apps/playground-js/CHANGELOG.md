# playground-js

## 0.0.2

### Patch Changes

- Updated dependencies [bfdc861]
  - shadcn-svelte@0.7.0
