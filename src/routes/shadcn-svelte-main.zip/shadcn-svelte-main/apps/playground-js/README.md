## Using the playground

1. Run the dev server of `www`, ensuring it's running on port 5173.
2. Run `pnpm scn <command_here>` to run a command in the playground.
3. Run `pnpm reset` to reset the scn-specific configurations of the playground.
