<script>
	import "../app.pcss";
</script>

<slot />
