# www

## 0.1.0

### Minor Changes

- d733f29: Update `Slider` component to latest Bits UI API

## 0.0.6

### Patch Changes

- 1ba3100: fix: add mode-watcher to Sonner registry dependencies

## 0.0.5

### Patch Changes

- 9c21525: safelist `"dark"` in tailwind config for out-of-the-box dark mode support

## 0.0.4

### Patch Changes

- 9c10deb: fix: typo in svelte4 warnings

## 0.0.3

### Patch Changes

- 78962e9: add warnings for svelte v4 support

## 0.0.2

### Patch Changes

- 82eaa35: Textarea: Replaced default `h-20` to `min-h-[80px]` to allow rows to adjust height.
