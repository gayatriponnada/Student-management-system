# shadcn-svelte

[shadcn/ui](https://ui.shadcn.com/docs), but for Svelte.
