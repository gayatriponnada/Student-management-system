<script lang="ts">
</script>

<nav
	class="grid gap-4 text-sm text-muted-foreground"
	data-x-chunk-name="dashboard-04-chunk-0"
	data-x-chunk-description="A sidebar navigation with links to general, security, integrations, support, organizations, and advanced settings."
	data-x-chunk-container="chunk-container after:right-0"
>
	<a href="##" class="font-semibold text-primary"> General </a>
	<a href="##">Security</a>
	<a href="##">Integrations</a>
	<a href="##">Support</a>
	<a href="##">Organizations</a>
	<a href="##">Advanced</a>
</nav>
