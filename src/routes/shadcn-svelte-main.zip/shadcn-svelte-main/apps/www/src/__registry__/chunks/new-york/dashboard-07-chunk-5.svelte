<script lang="ts">
	import { Button } from "$lib/registry/new-york/ui/button/index.js";
	import * as Card from "$lib/registry/new-york/ui/card/index.js";
</script>

<Card.Root
	data-x-chunk-name="dashboard-07-chunk-5"
	data-x-chunk-description="A card with a call to action to archive the product"
>
	<Card.Header>
		<Card.Title>Archive Product</Card.Title>
		<Card.Description>
			Lipsum dolor sit amet, consectetur adipiscing elit.
		</Card.Description>
	</Card.Header>
	<Card.Content>
		<div></div>
		<Button size="sm" variant="secondary">Archive Product</Button>
	</Card.Content>
</Card.Root>
