<script lang="ts">
	import { Bar } from "$lib/components/docs/charts/index.js";
</script>

<Bar />
