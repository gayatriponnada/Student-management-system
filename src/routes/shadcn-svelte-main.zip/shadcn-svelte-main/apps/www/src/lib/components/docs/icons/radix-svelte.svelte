<script lang="ts">
	import type { SVGAttributes } from "svelte/elements";

	type $$Props = SVGAttributes<SVGElement>;
</script>

<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" {...$$restProps}>
	<path
		fill-rule="evenodd"
		clip-rule="evenodd"
		d="M5.71429 4H14.8572C16.7507 4 18.2857 5.53502 18.2857 7.42857C18.2857 9.32213 16.7507 10.8571 14.8572 10.8571H12.5714V20H11.4286C8.27267 20 5.71429 17.4416 5.71429 14.2857V4ZM10.2857 10.8571H8.00001V14.2857C8.00001 15.7785 8.95408 17.0485 10.2857 17.5192V10.8571ZM8.00001 8.57143H14.8572C15.4883 8.57143 16 8.05975 16 7.42857C16 6.7974 15.4883 6.28571 14.8572 6.28571H8.00001V8.57143Z"
		fill="currentcolor"
	/>
</svg>
