<h3 class="font-heading mt-8 scroll-m-20 font-semibold tracking-tight">
	<slot />
</h3>
