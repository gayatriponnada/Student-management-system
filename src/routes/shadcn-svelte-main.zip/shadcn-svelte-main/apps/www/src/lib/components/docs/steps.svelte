<div class="[&>h3]:step steps mb-12 ml-4 border-l pl-8 [counter-reset:step]" {...$$restProps}>
	<slot />
</div>
