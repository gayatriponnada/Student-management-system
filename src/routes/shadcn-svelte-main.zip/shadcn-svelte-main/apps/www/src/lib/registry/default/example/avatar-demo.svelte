<script lang="ts">
	import * as Avatar from "$lib/registry/default/ui/avatar/index.js";
</script>

<Avatar.Root>
	<Avatar.Image src="https://github.com/shadcn.png" alt="@shadcn" />
	<Avatar.Fallback>CN</Avatar.Fallback>
</Avatar.Root>
