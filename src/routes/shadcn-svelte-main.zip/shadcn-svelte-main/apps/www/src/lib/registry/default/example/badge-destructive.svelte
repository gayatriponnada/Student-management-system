<script lang="ts">
	import { Badge } from "$lib/registry/default/ui/badge/index.js";
</script>

<Badge variant="destructive">Destructive</Badge>
