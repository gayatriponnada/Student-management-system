<script lang="ts">
	import ChevronRight from "lucide-svelte/icons/chevron-right";
	import { Button } from "$lib/registry/default/ui/button/index.js";
</script>

<Button variant="outline" size="icon">
	<ChevronRight class="h-4 w-4" />
</Button>
