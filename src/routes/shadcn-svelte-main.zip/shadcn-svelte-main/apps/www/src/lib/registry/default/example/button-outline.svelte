<script lang="ts">
	import { Button } from "$lib/registry/default/ui/button/index.js";
</script>

<Button variant="outline">Outline</Button>
