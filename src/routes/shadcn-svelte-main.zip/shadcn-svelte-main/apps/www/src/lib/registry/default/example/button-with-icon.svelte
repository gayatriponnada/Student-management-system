<script lang="ts">
	import Mail from "lucide-svelte/icons/mail";
	import { Button } from "$lib/registry/default/ui/button/index.js";
</script>

<Button>
	<Mail class="mr-2 h-4 w-4" />
	Login with Email
</Button>
