<script lang="ts">
	import { Input } from "$lib/registry/default/ui/input/index.js";
</script>

<Input type="email" placeholder="email" class="max-w-xs" />
