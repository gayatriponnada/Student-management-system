<script lang="ts">
	import { Slider } from "$lib/registry/default/ui/slider/index.js";
</script>

<Slider value={[50]} max={100} step={1} class="max-w-[70%]" />
