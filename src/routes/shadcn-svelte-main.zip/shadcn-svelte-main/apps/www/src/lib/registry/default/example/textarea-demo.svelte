<script lang="ts">
	import { Textarea } from "$lib/registry/default/ui/textarea/index.js";
</script>

<Textarea placeholder="Type your message here." />
