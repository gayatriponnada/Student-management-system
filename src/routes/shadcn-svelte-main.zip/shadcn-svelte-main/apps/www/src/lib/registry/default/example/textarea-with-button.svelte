<script lang="ts">
	import { Button } from "$lib/registry/default/ui/button/index.js";
	import { Textarea } from "$lib/registry/default/ui/textarea/index.js";
</script>

<div class="grid w-full gap-2">
	<Textarea placeholder="Type your message here." />
	<Button>Send message</Button>
</div>
