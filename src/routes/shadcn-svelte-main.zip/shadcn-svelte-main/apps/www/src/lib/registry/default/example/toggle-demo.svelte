<script lang="ts">
	import Bold from "lucide-svelte/icons/bold";
	import { Toggle } from "$lib/registry/default/ui/toggle/index.js";
</script>

<Toggle aria-label="toggle bold">
	<Bold class="h-4 w-4" />
</Toggle>
