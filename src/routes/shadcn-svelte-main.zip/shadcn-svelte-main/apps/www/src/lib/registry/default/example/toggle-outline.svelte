<script lang="ts">
	import Italic from "lucide-svelte/icons/italic";
	import { Toggle } from "$lib/registry/default/ui/toggle/index.js";
</script>

<Toggle variant="outline" aria-label="Toggle italic">
	<Italic class="h-4 w-4" />
</Toggle>
