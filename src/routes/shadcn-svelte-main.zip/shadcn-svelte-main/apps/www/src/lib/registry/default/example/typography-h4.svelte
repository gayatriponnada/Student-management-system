<h4 class="scroll-m-20 text-xl font-semibold tracking-tight">People stopped telling jokes</h4>
